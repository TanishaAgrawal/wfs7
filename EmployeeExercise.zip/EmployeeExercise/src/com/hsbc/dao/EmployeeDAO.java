package com.hsbc.dao;

import java.util.List;

import com.hsbc.model.Employee;

public interface EmployeeDAO {
	/*public List<Employee> getIdAsc(Employee e);
	public List<Employee> getIdDes(Employee e);
	public localDate getDOBAsc(Employee e);
	public localDate getDOBDes(Employee e);*/
	public void store(Employee emp);
	public List<Employee>getEmployee();
}
