package hsbc.com.main;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import com.hsbc.dao.EmployeeDAOImpl;
import com.hsbc.model.Employee;

public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int option=0;
		Scanner scan=new Scanner(System.in);
		EmployeeDAOImpl daoImpl=new EmployeeDAOImpl();
		do
		{
			System.out.println("1: Store 2: Sort 3: Exit");
			option=scan.nextInt();
			switch(option)
			{
			case 1:
				Employee employee=new Employee();
				System.out.println("Enter ID");
				employee.setId(scan.nextInt());
				System.out.println("Enter Name");
				employee.setName(scan.next());
				System.out.println("Enter Salary");
				employee.setSalary(scan.nextDouble());
				System.out.println("Enter Date");
				LocalDate dob=LocalDate.parse(scan.next());
				employee.setDob(dob);
				daoImpl.store(employee);
				break;
			case 2:
				System.out.println("1: Sort by ID in asc 2: Sort by ID in des 3: Sort by DOB in asc 4: Sort by DOB in des");
				option=scan.nextInt();
				List<Employee>employees=daoImpl.getEmployee();
				if(option==1)
				{
					Collections.sort(employees,(e1,e2)->e1.getId()-e2.getId());
					System.out.println(employees);
				}
				if(option==2)
				{
					Collections.sort(employees,(e1,e2)->e2.getId()-e1.getId());
					System.out.println(employees);
				}
				if(option==3)
				{
					Collections.sort(employees,(e1,e2)->e1.getDob().compareTo(e2.getDob()));
					System.out.println(employees);
				}
				if(option==4)
				{
					Collections.sort(employees,(e1,e2)->e2.getDob().compareTo(e1.getDob()));
					System.out.println(employees);
				}
				break;
			}
		}while(option!=0);

	}

}
