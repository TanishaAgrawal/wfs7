package com.hsbc.dao;

import java.util.ArrayList;
import java.util.List;

import com.hsbc.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO{
	
	private static List<Employee> employees=new ArrayList<Employee>();
	
	@Override
	public void store(Employee emp) {
		// TODO Auto-generated method stub
		employees.add(emp);
		
	}

	@Override
	public List<Employee> getEmployee() {
		// TODO Auto-generated method stub
		List<Employee> top=new ArrayList<Employee>();
		int counter=0;
		for(Employee e:employees)
		{
			top.add(e);
			counter++;
			if(counter==3)
				break;
		}
		
		return top;
	}
}
	//USED LAMDA FUNCTION IN MAIN METHOD
/*
	@Override
	public List<Employee> getIdAsc(Employee e) {
		// TODO Auto-generated method stub
		List<Employee>emp=null;
		Collections.sort(emp,new Comparator<Employee>() {
		public int compare(Employee o1,Employee o2)
		{
			return o1.getId()-o2.getId();
		}
		});
		return emp;
		
	}

	@Override
	public List<Employee> getIdDes(Employee e) {
		List<Employee>emp=null;
		Collections.sort(emp,new Comparator<Employee>() {
		public int compare(Employee o1,Employee o2)
		{
			return o2.getId()-o1.getId();
		}
	});
		return emp;
	}
*/
	